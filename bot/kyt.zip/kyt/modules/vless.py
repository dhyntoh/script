from kyt import *

#delete
@bot.on(events.CallbackQuery(data=b'delete7-vless'))
async def delete_vless(event):
	async def delete_vless_(event):
		async with bot.conversation(chat) as user:
			cmd2 = f" cat /etc/xray/config.json | grep '^#vmg' |  cut -d ' ' -f 2-3 | nl -s ') '".strip()
			x = subprocess.check_output(cmd2, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
			z = subprocess.check_output(cmd2, shell=True).decode("ascii")
			await event.edit(f"""
━━━━━━━━━━━━━━━━━━━━━━━━━━
<b>🗑️ DELETE vless USER</b>
━━━━━━━━━━━━━━━━━━━━━━━━━━
<code>{z}</code>
━━━━━━━━━━━━━━━━━━━━━━━━━━
<b>👉 Input Number to Delete:</b>
<i>/cancel to Cancel</i>
""")
			user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			user = (await user).raw_text
		per = "/cancel"
		if user == per:
			await event.respond(f"""<b>❌ PROCESS CANCELED</b>""",buttons=[[Button.inline("‹ Back ›","menu")]])
		else:
			cmd = f'printf "%s\n" "4" "{user}" | m-vless | sleep 2 | exit'
			subprocess.check_output(cmd, shell=True)
			await event.respond(f"""<b>✅ SUCCESSFULLY DELETED</b>""",buttons=[[Button.inline("‹ Back ›","menu")]])
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await delete_vless_(event)
	else:
		await event.answer("Akses Ditolak",alert=True)

#renew
@bot.on(events.CallbackQuery(data=b'renew7-vless'))
async def renew_vless(event):
	async def renew_vless_(event):
		async with bot.conversation(chat) as user:
			cmd2 = f" cat /etc/xray/config.json | grep '^#vmg' |  cut -d ' ' -f 2-3 | nl -s ') '".strip()
			x = subprocess.check_output(cmd2, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
			z = subprocess.check_output(cmd2, shell=True).decode("ascii")
			await event.edit(f"""
━━━━━━━━━━━━━━━━━━━━━━━━━━
<b>🔄 RENEW vless USER</b>
━━━━━━━━━━━━━━━━━━━━━━━━━━
<code>{z}</code>
━━━━━━━━━━━━━━━━━━━━━━━━━━
<b>👉 Input Number to Renew:</b>
<i>/cancel to Cancel</i>
""")
			user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			user = (await user).raw_text
		per = "/cancel"
		if user == per:
			await event.respond(f"""<b>❌ PROCESS CANCELED</b>""",buttons=[[Button.inline("‹ Back ›","menu")]])
		else:
			async with bot.conversation(chat) as exp:
				await event.respond(f"""<b>👉 Input Extra Days (e.g., 30):</b>""")
				exp = exp.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
				exp = (await exp).raw_text
			cmd = f'printf "%s\n" "3" "{user}" "{exp}" | m-vless | sleep 2 | exit'
			subprocess.check_output(cmd, shell=True)
			await event.respond(f"""<b>✅ SUCCESSFULLY RENEWED</b>""",buttons=[[Button.inline("‹ Back ›","menu")]])
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await renew_vless_(event)
	else:
		await event.answer("Akses Ditolak",alert=True)


#limit
@bot.on(events.CallbackQuery(data=b'limit7-vless'))
async def limit_vless(event):
	async def limit_vmess_(event):
		async with bot.conversation(chat) as user:
			cmd2 = f" cat /etc/xray/config.json | grep '^#vmg' |  cut -d ' ' -f 2-3 | nl -s ') '".strip()
			x = subprocess.check_output(cmd2, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
			z = subprocess.check_output(cmd2, shell=True).decode("ascii")
			await event.edit(f"""
━━━━━━━━━━━━━━━━━━━━━━━━━━
<b>⚡ CHANGE LIMIT/QUOTA</b>
━━━━━━━━━━━━━━━━━━━━━━━━━━
<code>{z}</code>
━━━━━━━━━━━━━━━━━━━━━━━━━━
<b>👉 Input Number:</b>
<i>/cancel to Cancel</i>
""")
			user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			user = (await user).raw_text
		per = "/cancel"
		if user == per:
			await event.respond(f"""<b>❌ PROCESS CANCELED</b>""",buttons=[[Button.inline("‹ Back ›","menu")]])
		else:
			async with bot.conversation(chat) as exp:
				await event.respond(f"""<b>👉 Input New IP Limit:</b>""")
				exp = exp.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
				exp = (await exp).raw_text
			async with bot.conversation(chat) as pw:
				await event.respond(f"""<b>👉 Input New Quota (GB):</b>""")
				pw = pw.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
				pw = (await pw).raw_text
			cmd = f'printf "%s\n" "7" "{user}" "{exp}" "{pw}" | m-vmess | sleep 2 | exit'
			subprocess.check_output(cmd, shell=True)
			await event.respond(f"""<b>✅ LIMIT UPDATED SUCCESSFULLY</b>""",buttons=[[Button.inline("‹ Back ›","menu")]])
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await limit_vmess_(event)
	else:
		await event.answer("Akses Ditolak",alert=True)

#CekConfig
@bot.on(events.CallbackQuery(data=b'akun7-vmess'))
async def akun_vmess(event):
	async def akun_vmess_(event):
		async with bot.conversation(chat) as user:
			cmd2 = f" cat /etc/xray/config.json | grep '^#vmg' |  cut -d ' ' -f 2-3 | nl -s ') '".strip()
			x = subprocess.check_output(cmd2, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
			z = subprocess.check_output(cmd2, shell=True).decode("ascii")
			await event.edit(f"""
━━━━━━━━━━━━━━━━━━━━━━━━━━
<b>🔍 CHECK CONFIG</b>
━━━━━━━━━━━━━━━━━━━━━━━━━━
<code>{z}</code>
━━━━━━━━━━━━━━━━━━━━━━━━━━
<b>👉 Input Number:</b>
<i>/cancel to Cancel</i>
""")
			user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			user = (await user).raw_text
		per = "/cancel"
		if user == per:
			await event.respond(f"""<b>❌ PROCESS CANCELED</b>""",buttons=[[Button.inline("‹ Back ›","menu")]])
		else:
			cmd = f'printf "%s\n" "6" "{user}" | m-vmess | sleep 2 | exit'
			subprocess.check_output(cmd, shell=True)
			await event.respond(f"""<b>✅ CONFIG SENT TO USER</b>""",buttons=[[Button.inline("‹ Back ›","menu")]])
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await akun_vmess_(event)
	else:
		await event.answer("Akses Ditolak",alert=True)
		
		
#restore
@bot.on(events.CallbackQuery(data=b'restore7-vmess'))
async def restore_vmess(event):
	async def restore_vmess_(event):
		async with bot.conversation(chat) as user:
			cmd2 = f" cat /etc/vmess/akundelete | grep '^###' |  cut -d ' ' -f 2-3 | nl -s ') '".strip()
			x = subprocess.check_output(cmd2, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
			z = subprocess.check_output(cmd2, shell=True).decode("ascii")
			await event.edit(f"""
━━━━━━━━━━━━━━━━━━━━━━━━━━
<b>♻️ RESTORE USER</b>
━━━━━━━━━━━━━━━━━━━━━━━━━━
<code>{z}</code>
━━━━━━━━━━━━━━━━━━━━━━━━━━
<b>👉 Input Number to Restore:</b>
<i>/cancel to Cancel</i>
""")
			user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			user = (await user).raw_text
		per = "/cancel"
		if user == per:
			await event.respond(f"""<b>❌ PROCESS CANCELED</b>""",buttons=[[Button.inline("‹ Back ›","menu")]])
		else:
			async with bot.conversation(chat) as exp:
				await event.respond(f"""<b>👉 Input New Expired (day):</b>""")
				exp = exp.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
				exp = (await exp).raw_text
			async with bot.conversation(chat) as pw:
				await event.respond(f"""<b>👉 Input IP Limit:</b>""")
				pw = pw.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
				pw = (await pw).raw_text
			async with bot.conversation(chat) as pw2:
				await event.respond(f"""<b>👉 Input Quota (GB):</b>""")
				pw2 = pw2.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
				pw2 = (await pw2).raw_text
			cmd = f'printf "%s\n" "11" "{user}" "{exp}" "{pw}" "{pw2}" | m-vmess | sleep 2 | exit'
			subprocess.check_output(cmd, shell=True)
			await event.respond(f"""<b>✅ USER RESTORED</b>""",buttons=[[Button.inline("‹ Back ›","menu")]])
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await restore_vmess_(event)
	else:
		await event.answer("Akses Ditolak",alert=True)


#MultiLogin Login
@bot.on(events.CallbackQuery(data=b'loginip7-vmess'))
async def loginip_vmess(event):
	async def loginip_vmess_(event):
		async with bot.conversation(chat) as user:
			cmd2 = f" cat /etc/vmess/listlock | grep '^###' |  cut -d ' ' -f 2-3 | nl -s ') '".strip()
			x = subprocess.check_output(cmd2, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
			z = subprocess.check_output(cmd2, shell=True).decode("ascii")
			await event.edit(f"""
━━━━━━━━━━━━━━━━━━━━━━━━━━
<b>🔓 UNLOCK IP LIMIT</b>
━━━━━━━━━━━━━━━━━━━━━━━━━━
<code>{z}</code>
━━━━━━━━━━━━━━━━━━━━━━━━━━
<b>👉 Input Number to Unlock:</b>
<i>/cancel to Cancel</i>
""")
			user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			user = (await user).raw_text
		per = "/cancel"
		if user == per:
			await event.respond(f"""<b>❌ PROCESS CANCELED</b>""",buttons=[[Button.inline("‹ Back ›","menu")]])
		else:
			cmd = f'printf "%s\n" "9" "{user}" | m-vmess | sleep 2 | exit'
			subprocess.check_output(cmd, shell=True)
			await event.respond(f"""<b>✅ IP UNLOCKED</b>""",buttons=[[Button.inline("‹ Back ›","menu")]])
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await loginip_vmess_(event)
	else:
		await event.answer("Akses Ditolak",alert=True)
		
#MultiLogin Quota
@bot.on(events.CallbackQuery(data=b'logingb7-vmess'))
async def logingb_vless(event):
	async def logingb_vless_(event):
		async with bot.conversation(chat) as user:
			cmd2 = f" cat /etc/vless/userQuota | grep '^###' |  cut -d ' ' -f 2-3 | nl -s ') '".strip()
			x = subprocess.check_output(cmd2, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
			z = subprocess.check_output(cmd2, shell=True).decode("ascii")
			await event.edit(f"""
━━━━━━━━━━━━━━━━━━━━━━━━━━
<b>🔓 RESET QUOTA LIMIT</b>
━━━━━━━━━━━━━━━━━━━━━━━━━━
<code>{z}</code>
━━━━━━━━━━━━━━━━━━━━━━━━━━
<b>👉 Input Number to Reset:</b>
<i>/cancel to Cancel</i>
""")
			user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			user = (await user).raw_text
		per = "/cancel"
		if user == per:
			await event.respond(f"""<b>❌ PROCESS CANCELED</b>""",buttons=[[Button.inline("‹ Back ›","menu")]])
		else:
			cmd = f'printf "%s\n" "10" "{user}" | m-vless | sleep 2 | exit'
			subprocess.check_output(cmd, shell=True)
			await event.respond(f"""<b>✅ QUOTA RESET SUCCESS</b>""",buttons=[[Button.inline("‹ Back ›","menu")]])
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await logingb_vless_(event)
	else:
		await event.answer("Akses Ditolak",alert=True)
		
#CRATE vless
@bot.on(events.CallbackQuery(data=b'create7-vless'))
async def create_vless(event):
	async def create_vless_(event):
		async with bot.conversation(chat) as user:
			await event.edit(f"""
━━━━━━━━━━━━━━━━━━━━━━━━━━
<b>🆕 CREATE VLESS ACCOUNT</b>
━━━━━━━━━━━━━━━━━━━━━━━━━━
<b>Rules:</b>
• No Spasi & Karakter Aneh
• Jangan gunakan nama dobel

<b>👉 Input Username:</b>
<i>/cancel to Cancel</i>
""")
			user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			user = (await user).raw_text
		per = "/cancel"
		if user == per:
			await event.respond(f"""<b>❌ PROCESS CANCELED</b>""",buttons=[[Button.inline("‹ Back ›","menu")]])
		else:
			async with bot.conversation(chat) as exp:
				await event.respond(f"""<b>👉 Input Expired (Days):</b>""")
				exp = exp.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
				exp = (await exp).raw_text
			async with bot.conversation(chat) as pw:
				await event.respond(f"""<b>👉 Input IP Limit (0 = Unlimited):</b>""")
				pw = pw.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
				pw = (await pw).raw_text
			async with bot.conversation(chat) as pw2:
				await event.respond(f"""<b>👉 Input Quota GB (0 = Unlimited):</b>""")
				pw2 = pw2.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
				pw2 = (await pw2).raw_text
			cmd = f'printf "%s\n" "1" "{user}" "{exp}" "{pw}" "{pw2}" | m-vless | sleep 2 | exit'
			subprocess.check_output(cmd, shell=True)
			await event.respond(f"""
━━━━━━━━━━━━━━━━━━━━━━━━━━
<b>✅   VLESS ACCOUNT CREATED/b>
━━━━━━━━━━━━━━━━━━━━━━━━━━
<b>👤 Detail User:</b>
<code>Username : {user}</code>
<code>Expired  : {exp} Days</code>
<code>Limit IP : {pw}</code>
<code>Quota    : {pw2} GB</code>

<i>Account saved to database.</i>
━━━━━━━━━━━━━━━━━━━━━━━━━━
""",buttons=[[Button.inline("‹ Back ›","menu")]])
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await create_vless_(event)
	else:
		await event.answer("Akses Ditolak",alert=True)

# TRIAL vless
@bot.on(events.CallbackQuery(data=b'trial7-vless'))
async def trial_vless(event):
	async def trial_vless_(event):
		async with bot.conversation(chat) as exp:
			await event.edit(f"""
━━━━━━━━━━━━━━━━━━━━━━━━━━
<b>⏳ CREATE TRIAL vless</b>
━━━━━━━━━━━━━━━━━━━━━━━━━━
<b>👉 Input Duration (Minutes):</b>
<i>/cancel to Cancel</i>
""")
			exp = exp.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			exp = (await exp).raw_text
		per = "/cancel"
		if exp == per:
			await event.respond(f"""<b>❌ PROCESS CANCELED</b>""",buttons=[[Button.inline("‹ Back ›","menu")]])
		else:
			cmd = f'printf "%s\n" {2} "{exp}" | m-vless | sleep 2 | exit'
			subprocess.check_output(cmd, shell=True).decode("utf-8")
			await event.respond(f"""
━━━━━━━━━━━━━━━━━━━━━━━━━━
<b>✅ TRIAL ACCOUNT GENERATED</b>
━━━━━━━━━━━━━━━━━━━━━━━━━━
<code>Duration : {exp} Minutes</code>
<i>Account sent to user.</i>
━━━━━━━━━━━━━━━━━━━━━━━━━━
""",buttons=[[Button.inline("‹ Back ›","menu")]])
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await trial_vless_(event)
	else:
		await event.answer("Akses Ditolak",alert=True)

#CEK
@bot.on(events.CallbackQuery(data=b'cek7-vless'))
async def cek_vless(event):
	async def cek_vless_(event):
		cmd = 'bot-cek-ws'.strip()
		# PENTING: Backtick dihilangkan agar HTML parse bot-cek-ws berfungsi
		z = subprocess.check_output(cmd, shell=True).decode("utf-8")
		await event.edit(f"""
{z}
""",buttons=[[Button.inline("‹ Back ›","menu")]], parse_mode='html')
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await cek_vless_(event)
	else:
		await event.answer("Access Denied",alert=True)

@bot.on(events.CallbackQuery(data=b'login7-vless'))
async def vless(event):
	async def vless_(event):
		inline = [
			[Button.inline("UNLOCK LOGIN IP","loginip7-vless"), Button.inline("UNLOCK QUOTA","logingb7-vless")],
			[Button.inline("‹ Back ›","vless")]
		]
		await event.edit(buttons=inline)
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await vless_(event)
	else:
		await event.answer("Access Denied",alert=True)
		
@bot.on(events.CallbackQuery(data=b'vless'))
async def vless(event):
	async def vless_(event):
		inline = [
			[Button.inline("TRIAL","trial7-vless"), Button.inline("CREATE","create7-vless"), Button.inline("CHECK USER","cek7-vless")],
			[Button.inline("DELETE","delete7-vless"), Button.inline("UNLOCK","login7-vless"), Button.inline("LIMIT","limit7-vless")],
			[Button.inline("RENEW","renew7-vless"), Button.inline("RESTORE","restore7-vless"), Button.inline("CONFIG","akun7-vless")],
			[Button.inline("‹ BACK TO MENU ›","menu")]
		]
		z = requests.get(f"