from kyt import *

# ==========================================
#       DELETE SSH USER
# ==========================================
@bot.on(events.CallbackQuery(data=b'delete-ssh'))
async def delete_ssh(event):
	async def delete_ssh_(event):
		async with bot.conversation(chat) as user:
			await event.respond("<b>👉 Input Username to Delete:</b>")
			user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			user = (await user).raw_text
			cmd = f'printf "%s\n" "{user}" | delssh'
		try:
			# Menjalankan perintah hapus
			a = subprocess.check_output(cmd, shell=True).decode("utf-8")
		except:
			await event.respond(f"<b>❌ User</b> `{user}` <b>Not Found</b>")
		else:
			await event.respond(f"<b>✅ Successfully Deleted</b> `{user}`")
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await delete_ssh_(event)
	else:
		await event.answer("Akses Ditolak",alert=True)

# ==========================================
#       CREATE SSH ACCOUNT
# ==========================================
@bot.on(events.CallbackQuery(data=b'create-ssh'))
async def create_ssh(event):
	async def create_ssh_(event):
		async with bot.conversation(chat) as user:
			await event.respond('<b>👉 Input Username:</b>')
			user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			user = (await user).raw_text
		async with bot.conversation(chat) as pw:
			await event.respond("<b>👉 Input Password:</b>")
			pw = pw.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			pw = (await pw).raw_text
		async with bot.conversation(chat) as exp:
			await event.respond("<b>👉 Input Expired (Days):</b>")
			exp = exp.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			exp = (await exp).raw_text
		
		# Animasi Loading
		msg_loading = await event.edit("`Processing...`")
		time.sleep(1)
		
		# Perintah Membuat Akun
		cmd = f'useradd -e `date -d "{exp} days" +"%Y-%m-%d"` -s /bin/false -M {user} && echo "{pw}\n{pw}" | passwd {user}'
		try:
			subprocess.check_output(cmd,shell=True)
		except:
			await event.respond("<b>❌ User Already Exists / Error</b>")
		else:
			today = DT.date.today()
			later = today + DT.timedelta(days=int(exp))
			
			# Tampilan Struk Premium
			msg = f"""
━━━━━━━━━━━━━━━━━━━━━━━━━━
<b>✅ SSH ACCOUNT CREATED</b>
━━━━━━━━━━━━━━━━━━━━━━━━━━
<b>👤 Account Details:</b>
<code>Username : {user.strip()}</code>
<code>Password : {pw.strip()}</code>
<code>Expired  : {later}</code>

<b>🔌 Connection Info:</b>
<code>Domain   : {DOMAIN}</code>
<code>IP Addr  : {ipsaya}</code>
<code>OpenSSH  : 22</code>
<code>Dropbear : 109, 143</code>
<code>WS HTTP  : 80, 8080</code>
<code>WS SSL   : 443</code>
<code>UDP GW   : 7100, 7200, 7300</code>
<code>UDP ZIVPN: 7400</code>

<b>🔗 Payload Example:</b>
<code>GET / HTTP/1.1[crlf]Host: {DOMAIN}[crlf]Upgrade: websocket[crlf][crlf]</code>
━━━━━━━━━━━━━━━━━━━━━━━━━━
"""
			await event.respond(msg)
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await create_ssh_(event)
	else:
		await event.answer("Akses Ditolak",alert=True)

# ==========================================
#       SHOW SSH MEMBERS
# ==========================================
@bot.on(events.CallbackQuery(data=b'show-ssh'))
async def show_ssh(event):
	async def show_ssh_(event):
		cmd = 'bot-member-ssh'.strip()
		# PENTING: Mengambil output dari script bash yang sudah kita percantik sebelumnya
		z = subprocess.check_output(cmd, shell=True).decode("utf-8")
		
		# Menggunakan parse_mode html agar format dari bash script terbaca
		await event.respond(f"""
{z}
""",buttons=[[Button.inline("‹ Back ›","menu")]], parse_mode='html')
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await show_ssh_(event)
	else:
		await event.answer("Access Denied",alert=True)


# ==========================================
#       TRIAL SSH ACCOUNT
# ==========================================
@bot.on(events.CallbackQuery(data=b'trial-ssh'))
async def trial_ssh(event):
	async def trial_ssh_(event):
		exp = "1"
		user = "Trial-"+str(random.randint(100,1000))
		pw = "1"
		await event.edit("`Generating Trial Account...`")
		time.sleep(1)
		
		cmd = f'useradd -e `date -d "{exp} days" +"%Y-%m-%d"` -s /bin/false -M {user} && echo "{pw}\n{pw}" | passwd {user}'
		try:
			subprocess.check_output(cmd,shell=True)
		except:
			await event.respond("**❌ Error Generating Trial**")
		else:
			today = DT.date.today()
			later = today + DT.timedelta(days=int(exp))
			msg = f"""
━━━━━━━━━━━━━━━━━━━━━━━━━━
<b>⏳ SSH TRIAL ACCOUNT</b>
━━━━━━━━━━━━━━━━━━━━━━━━━━
<b>👤 Account Details:</b>
<code>Username : {user.strip()}</code>
<code>Password : {pw.strip()}</code>
<code>Expired  : 24 Hours</code>

<b>🔌 Connection Info:</b>
<code>Domain   : {DOMAIN}</code>
<code>IP Addr  : {ipsaya}</code>
<code>OpenSSH  : 22</code>
<code>Dropbear : 109, 143</code>
<code>WS SSL   : 443</code>
<code>UDP GW   : 7100-7300</code>
code>UDP ZIVPN : 7400</code>
━━━━━━━━━━━━━━━━━━━━━━━━━━
<b>🤖 @{sender.username}</b>
"""
			await event.respond(msg)
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await trial_ssh_(event)
	else:
		await event.answer("Akses Ditolak",alert=True)
		
# ==========================================
#       CHECK LOGIN SSH
# ==========================================
@bot.on(events.CallbackQuery(data=b'login-ssh'))
async def login_ssh(event):
	async def login_ssh_(event):
		cmd = 'bot-cek-login-ssh'.strip()
		# Mengambil output dari script bash monitoring login
		z = subprocess.check_output(cmd, shell=True).decode("utf-8")
		
		await event.respond(f"""
{z}
""",buttons=[[Button.inline("‹ Back ›","menu")]], parse_mode='html')
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await login_ssh_(event)
	else:
		await event.answer("Access Denied",alert=True)


# ==========================================
#       MAIN MENU SSH
# ==========================================
@bot.on(events.CallbackQuery(data=b'ssh'))
async def ssh(event):
	async def ssh_(event):
		inline = [
			[Button.inline("TRIAL","trial-ssh"), Button.inline("CREATE","create-ssh")],
			[Button.inline("DELETE USER","delete-ssh"), Button.inline("CHECK LOGIN","login-ssh")],
			[Button.inline("MEMBER LIST","show-ssh"), Button.inline("‹ BACK TO MENU ›","menu")]
		]
		z = requests.get(f"http://ip-api.com/json/?fields=country,region,city,timezone,isp").json()
		msg = f"""
━━━━━━━━━━━━━━━━━━━━━━━━━━
<b>🛡 SSH & OVPN MANAGER</b>
━━━━━━━━━━━━━━━━━━━━━━━━━━
<b>Service Information:</b>
<code>┌─ Protocol : SSH/OVPN</code>
<code>├─ Host     : {DOMAIN}</code>
<code>├─ ISP      : {z["isp"]}</code>
<code>└─ Region   : {z["country"]}</code>
━━━━━━━━━━━━━━━━━━━━━━━━━━
<i>Silakan pilih opsi manajemen di bawah:</i>
"""
		await event.edit(msg,buttons=inline)
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await ssh_(event)
	else:
		await event.answer("Access Denied",alert=True)
